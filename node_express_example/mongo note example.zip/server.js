const express = require('express');
const { MONGO_URL, PORT } = require('./config');
const router = require('./routes');
const mongoose = require('mongoose');

const server = express();

server.use(express.json())
server.use(router);

const connectToMongoose = () => {
  mongoose.connect(MONGO_URL)
}


server.listen(PORT, () => {
  console.log(`Listening on port ${PORT}`);
  connectToMongoose();
})