import './App.css';
import React, { Component, useState } from 'react';
import { ColorToggles } from './components/ColorToggles';
import { ColorDisplay } from './components/ColorDisplay';
/* 
  1. Knobs that control the different colors
  2. User changes knobs, and a box with that color chnages

*/



// function App() {
//   const [name, setName] = useState('John');
//   const [red, setRed] = useState(0)
//   const [blue, setBlue] = useState(0)
//   const [green, setgreen] = useState(0)
//   return (
//     <div className="App App-header">
      
//     </div>
//   );
// }

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: 'Tom',
      showSplashScreen: true,
      red: 0,
      green: 0,
      blue: 0,
      colorHistory: []
    }
    this.hideSplash = this.hideSplash.bind(this)
  }


  handleColorChange = (event) => {
    const colorValue = parseInt(event.target.value);
    console.log(colorValue, 'COLOR value');
    const colorName = event.target.id;
    console.log(colorName, 'Color name')
    this.setState({
      [colorName]: colorValue
    })
  }

  hideSplash () {
    // this.state.showSplashScreen = false; // We cannot mutate the state directly!

    this.setState({
      showSplashScreen: false
    })
  }

  saveColor = () => {
    const {red, green, blue} = this.state;
    this.setState({
      colorHistory: [...this.state.colorHistory, {red, green, blue}]
    })
  }


  render() {
    return (
      <div className="App App-header">
        
          {
            this.state.showSplashScreen ? 
            (
              <div id="welcome">
                <h1>{this.state.name}, welcome to the color picker!</h1>
              <button onClick={this.hideSplash}>Enter</button>
              </div>
            ) : (
            <div>
              <ColorDisplay size="large" red={this.state.red} green={this.state.green} blue={this.state.blue}/>
              
              <ColorToggles
                handleColorChange={this.handleColorChange}
                red={this.state.red}
                green={this.state.green}
                blue={this.state.blue}
              />
              
              <button onClick={this.saveColor}>Save Color</button>

              <div id="colorHistory">
                {this.state.colorHistory.map((color) => {
                  return (
                    <ColorDisplay
                      size="small"
                      red={color.red}
                      green={color.green}
                      blue={color.blue}
                    />
                  )
                })}
              </div>

            </div>

            )
            

          }
      </div>
    );
  }

}



export default App;
