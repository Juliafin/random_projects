module.exports = {
  PORT: 13000,
  SECRET: 'ASDFLKAWJE"RP(@#$KNDZF"T(@#4'
}