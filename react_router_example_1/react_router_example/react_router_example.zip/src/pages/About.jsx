import React from 'react';
import './About.css'

export const About = () => {
  return (
    <div className="container">About</div>
  )
};
