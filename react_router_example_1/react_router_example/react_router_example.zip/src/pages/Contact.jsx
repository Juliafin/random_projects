import React from 'react';
import './Contact.css'

export const Contact = (props) => {
  return (
    <div className="container">Contact us at {props.phoneNumber} </div>
  )
};
