import React from 'react';

export const Redirected = () => {
  return (
    <div>This is a generic 404!</div>
  )
}
;