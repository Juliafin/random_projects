export const SET_COLOR = 'SET_COLOR';

export const ADD_ENTRY = 'ADD_ENTRY';