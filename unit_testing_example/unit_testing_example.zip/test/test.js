const {expect} = require('chai');
const appendToEndAndBeginningArray = require('../src/function1');

describe('test.js', () => {
  
  describe('appendToEndAndBeginningArray', () => {
    var arr1;
    var elementToAppend;

    beforeEach(() => {
      // Setup
        arr1 = [1,2,3];
        elementToAppend = "hello";
    });

    it('should output an array', () => {
      var result = appendToEndAndBeginningArray(arr1, elementToAppend);

      expect(result).to.be.a('array');

    });

    it('should append elements to the beginning and end of an array that is not empty', () => {


      // Execution
      var result = appendToEndAndBeginningArray(arr1, elementToAppend);

      // Assertions

      expect(result).to.contain(elementToAppend);
      expect(result[0]).to.equal(elementToAppend);
      expect(result[result.length - 1]).to.equal(elementToAppend);
      expect(arr1.length + 2).to.eql(result.length);

    });

    it('should have the right length after being called with an empty array', () => {
      const initialLength = arr1.length;

      const result = appendToEndAndBeginningArray(arr1);

      expect(result.length).to.equal(initialLength);
    })

    it('should throw a TypeError when provided something that is not an array', () => {
      
      var notAnArray = {};
      var expectedErrorMessage = 'The firs argument must be an array'

      expect(() => {appendToEndAndBeginningArray(notAnArray)}).to.throw(TypeError, expectedErrorMessage);

    });
  });


  describe('The thing we are testing', () => {
    it('The individual test', () => {
      
      expect(2).to.equal(2)
      
    });
    
    it('Checks that 2 is a number', () => {
      expect(2).to.be.a('number');
      expect(2).to.be.greaterThan(1);
    });

  });


});